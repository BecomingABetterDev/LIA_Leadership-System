import express from "express";
import {
  sendFeedback,
  respondToFeedback,
  listAllFeedbacks
} from "../controllers/feedbackController.js";

const router = express.Router();

router.post("/", sendFeedback);
router.put("/feedback/respond/:id", respondToFeedback);
router.get("/feedback", listAllFeedbacks);

export default router;
