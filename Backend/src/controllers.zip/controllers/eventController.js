import Event from "../models/Event.js";
import Applicant from "../models/Applicant.js";
import EventApplicationRequirement from "../models/EventApplicationRequirement.js";
import Comment from "../models/Comment.js";
import Reply from "../models/Reply.js";
import cloudinary from "../libs/cloudinary.js";
import Notification from "../models/Notification.js";
import SavanahTransaction from "../models/SavanahTransaction.js";
import { contract } from "../contract.js"; 
import { ethers } from "ethers";
import AdminSettings from "../models/AdminSettings.js";
// Create student event
export const createStudentEvent = async (req, res) => {
  try {
    const { title, description, detailedDescription, tokenValue, category, proposedDate, maxApplicants, location } = req.body;
    const event = await Event.create({
      title,
      description,
      detailedDescription,
      tokenValue,
      category,
      proposedDate,
      postedBy: req.student._id,
      maxApplicants,
      isPostedByAStudent: true,
      status: "pending",
      location
    });
    res.json({ message: "Event created", event });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Create leadership/admin event
export const createLeadershipEvent = async (req, res) => {
  try {
    const { title, description, tokenValue, category, proposedDate, maxApplicants, location } = req.body;
    const event = await Event.create({
      title, description, tokenValue, category, proposedDate, maxApplicants,
      postedBy: null, isPostedByAStudent: false, status: null, location
    });

    // Notify all students
    const students = await Student.find();
    await Notification.insertMany(
      students.map(s => ({
        recipient: s._id,
        type: "new_event",
        message: `New leadership event: ${title}`
      }))
    );

    res.json({ message: "Leadership event created", event });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// Apply to event with requirements
export const applyToEvent = async (req, res) => {
  try {
    const { eventId, requirementsFilled } = req.body;
    const studentID = req.student._id;

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    const eventRequirements = await EventApplicationRequirement.find({ eventID: eventId });
    if (eventRequirements.length > 0) {
      const filledIDs = requirementsFilled.map(r => r.requirementID);
      const allFilled = eventRequirements.every(r => filledIDs.includes(r._id.toString()));
      if (!allFilled) return res.status(400).json({ message: "All requirements must be filled" });

      for (const r of requirementsFilled) {
        const reqDoc = await EventApplicationRequirement.findById(r.requirementID);
        if (!reqDoc) continue;

        const updateData = { studentID };

        if (reqDoc.type === "image" && r.image) {
          // Upload to Cloudinary and save the URL
          const uploadResult = await cloudinary.uploader.upload(r.image);
          updateData.image = uploadResult.secure_url;
        } else if (reqDoc.type === "text") {
          updateData.text = r.text || null;
        }

        await EventApplicationRequirement.findByIdAndUpdate(
          r.requirementID,
          { $set: updateData },
          { new: true }
        );
      }
    }

    const existing = await Applicant.findOne({ event: eventId, studentID });
    if (existing) return res.status(400).json({ message: "Already applied" });

    const applicant = await Applicant.create({ event: eventId, studentID, status: "pending" });
    res.json({ message: "Applied successfully", applicant });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Count views
export const countEventView = async (req, res) => {
  try {
    const { eventId } = req.body;
    const studentID = req.student._id;

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    if (!event.views) event.views = [];
    if (!event.views.includes(studentID)) {
      event.views.push(studentID);
      await event.save();
    }

    res.json({ message: "View counted", totalViews: event.views.length });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// List events with comments & replies
export const listEvents = async (req, res) => {
  try {
    const events = await Event.find()
      .populate({
        path: "comments",
        populate: { path: "replies" }
      });
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Comments
export const addComment = async (req, res) => {
  try {
    const { eventID, text } = req.body;
    const comment = await Comment.create({ eventID, userID: req.student._id, text });

    // Notify event creator if not the same student
    const event = await Event.findById(eventID);
    if (event && event.postedBy?.toString() !== req.student._id.toString()) {
      await Notification.create({
        recipient: event.postedBy,
        type: "comment",
        message: `New comment on your event: ${text}`
      });
    }

    res.json({ message: "Comment added", comment });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const updateComment = async (req, res) => {
  try {
    const { commentId } = req.params;
    const { text } = req.body;
    const comment = await Comment.findByIdAndUpdate(commentId, { $set: { text } }, { new: true });
    if (!comment) return res.status(404).json({ message: "Comment not found" });
    res.json({ message: "Comment updated", comment });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const deleteComment = async (req, res) => {
  try {
    const { commentId } = req.params;
    const comment = await Comment.findByIdAndDelete(commentId);
    if (!comment) return res.status(404).json({ message: "Comment not found" });
    res.json({ message: "Comment deleted" });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// Replies
export const addReply = async (req, res) => {
  try {
    const { commentID, text } = req.body;
    const reply = await Reply.create({ commentID, userID: req.student._id, text });

    // Notify comment owner if not the same student
    const comment = await Comment.findById(commentID);
    if (comment && comment.userID.toString() !== req.student._id.toString()) {
      await Notification.create({
        recipient: comment.userID,
        type: "reply",
        message: `New reply to your comment: ${text}`
      });
    }

    res.json({ message: "Reply added", reply });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const updateReply = async (req, res) => {
  try {
    const { replyId } = req.params;
    const { text } = req.body;
    const reply = await Reply.findByIdAndUpdate(replyId, { $set: { text } }, { new: true });
    if (!reply) return res.status(404).json({ message: "Reply not found" });
    res.json({ message: "Reply updated", reply });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const deleteReply = async (req, res) => {
  try {
    const { replyId } = req.params;
    const reply = await Reply.findByIdAndDelete(replyId);
    if (!reply) return res.status(404).json({ message: "Reply not found" });
    res.json({ message: "Reply deleted" });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// Requirements
export const addRequirement = async (req, res) => {
  try {
    const { eventID, name, type, image, text, maxWord } = req.body;
    const requirement = await EventApplicationRequirement.create({ eventID, name, type, image, text, maxWord });
    res.json({ message: "Requirement added", requirement });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const deleteRequirement = async (req, res) => {
  try {
    const { requirementId } = req.params;
    const reqDoc = await EventApplicationRequirement.findByIdAndDelete(requirementId);
    if (!reqDoc) return res.status(404).json({ message: "Requirement not found" });
    res.json({ message: "Requirement deleted" });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// Leadership/Admin actions
export const approveEvent = async (req, res) => {
  try {
    const { eventId, amount, bonusGiven = 0, deductedMark = 0, description } = req.body;

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });
    if (!event.isPostedByAStudent) return res.status(400).json({ message: "Only student-prepared events apply here" });

    // Update event status
    event.status = "approved";
    await event.save();

    // Notify the student who submitted the event
    if (event.postedBy) {
      await Notification.create({
        recipient: event.postedBy,
        type: "application_approved",
        message: `Your event "${event.title}" has been approved!`
      });
    }

    // Notify all students about the new available event
    const students = await Student.find();
    await Notification.insertMany(
      students.map(s => ({
        recipient: s._id,
        type: "new_event",
        message: `A new event is now available: "${event.title}"`
      }))
    );

    // Optionally mint tokens and record transaction for the student who submitted the event
    if (event.postedBy && amount > 0) {
      const student = await Student.findById(event.postedBy);
      if (student) {
        const tx = await contract.mint(student._id, ethers.parseUnits(amount.toString(), 18));
        await tx.wait();
        student.tokenBalance += Number(amount);
        await student.save();

        await SavanahTransaction.create({
          studentID: student._id,
          eventId: event._id,
          bonusGiven,
          deductedMark,
          description: description || "Event approved transaction"
        });
      }
    }

    res.json({ message: "Event approved, student notified, and all students alerted about the new event", event });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const rejectEvent = async (req, res) => {
  try {
    const { eventId, rejectionReason } = req.body;
    if (!rejectionReason) return res.status(400).json({ message: "Rejection reason required" });
    const event = await Event.findByIdAndUpdate(
      eventId,
      { $set: { status: "rejected", rejectionReason } },
      { new: true }
    );
    if (!event) return res.status(404).json({ message: "Event not found" });

    // Notify student
    if (event.postedBy) {
      await Notification.create({
        recipient: event.postedBy,
        type: "application_rejected",
        message: `Your event "${event.title}" was rejected. Reason: ${rejectionReason}`
      });
    }

    res.json({ message: "Event rejected", event });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const updateEventDate = async (req, res) => {
  try {
    const { eventId, proposedDate } = req.body;
    const event = await Event.findByIdAndUpdate(eventId, { $set: { proposedDate } }, { new: true });
    if (!event) return res.status(404).json({ message: "Event not found" });
    res.json({ message: "Event date updated", event });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const updateMaxApplicants = async (req, res) => {
  try {
    const { eventId, maxApplicants } = req.body;
    const event = await Event.findByIdAndUpdate(eventId, { $set: { maxApplicants } }, { new: true });
    if (!event) return res.status(404).json({ message: "Event not found" });
    res.json({ message: "Max applicants updated", event });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const cancelEvent = async (req, res) => {
  try {
    const { eventId } = req.body;
    const event = await Event.findByIdAndDelete(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });
    res.json({ message: "Event cancelled" });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

export const completeEvent = async (req, res) => {
  try {
    const { eventId } = req.body;

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ message: "Event not found" });

    const requirements = await EventApplicationRequirement.find({ eventID: eventId });
    for (const reqItem of requirements) {
      if (reqItem.image) {
        await cloudinary.uploader.destroy(reqItem.image);
      }
    }

    event.isCompleted = true;
    await event.save();

    res.json({ message: "Event completed, all student requirement images deleted", event });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const endEventApplications = async (req, res) => {
  try {
    const { eventId } = req.body;
    const event = await Event.findByIdAndUpdate(eventId, { $set: { status: "approved", isApplicationEnded: true } }, { new: true });
    if (!event) return res.status(404).json({ message: "Event not found" });
    res.json({ message: "Event applications ended", event });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

// Approve Applicant
export const approveApplicant = async (req, res) => {
  try {
    const { applicantId } = req.body;
    const applicant = await Applicant.findById(applicantId);
    if (!applicant) return res.status(404).json({ message: "Applicant not found" });

    applicant.status = "approved";
    await applicant.save();

    // Notify the student
    await Notification.create({
      recipient: applicant.studentID,
      type: "application_approved",
      message: `Your application for event "${applicant.event}" has been approved!`
    });

    res.json({ message: "Applicant approved", applicant });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Reject Applicant
export const rejectApplicant = async (req, res) => {
  try {
    const { applicantId, rejectionReason } = req.body;
    if (!rejectionReason) return res.status(400).json({ message: "Rejection reason required" });

    const applicant = await Applicant.findById(applicantId);
    if (!applicant) return res.status(404).json({ message: "Applicant not found" });

    applicant.status = "rejected";
    applicant.rejectionReason = rejectionReason;
    await applicant.save();

    // Notify the student
    await Notification.create({
      recipient: applicant.studentID,
      type: "application_rejected",
      message: `Your application for event "${applicant.event}" was rejected. Reason: ${rejectionReason}`
    });

    res.json({ message: "Applicant rejected", applicant });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Mark Notification(s) as Read
export const markNotificationRead = async (req, res) => {
  try {
    const { notificationIds } = req.body; // array or single ID
    if (!notificationIds) return res.status(400).json({ message: "Notification ID(s) required" });

    if (Array.isArray(notificationIds)) {
      await Notification.updateMany(
        { _id: { $in: notificationIds } },
        { $set: { isRead: true } }
      );
    } else {
      await Notification.findByIdAndUpdate(notificationIds, { $set: { isRead: true } });
    }

    res.json({ message: "Notification(s) marked as read" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const listApplicants = async (req, res) => {
  try {
    const applicants = await Applicant.find()
    res.json(applicants);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const listTransactions = async (req, res) => {
  try {
    const transactions = await SavanahTransaction.find()
    res.json(transactions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const listNotifications = async (req, res) => {
  try {
    const notifications = await Notification.find()
    res.json(notifications);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const getAdminSettings = async (req, res) => {
  try {
    const settings = await AdminSettings.find()
    res.json(settings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};