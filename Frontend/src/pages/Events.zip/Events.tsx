import { useState, useRef } from "react";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SearchInput } from "@/components/ui/search-input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Link } from "react-router-dom";
import {
  Calendar,
  MapPin,
  Users,
  MessageCircle,
  User,
  CalendarX,
  Send,
  Reply,
  Pencil,
  Trash2,
  X,
  Check,
  CornerDownRight,
  Ban,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  Upload,
  Image as ImageIcon,
  AlertTriangle,
} from "lucide-react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

interface Comment {
  id: number;
  user: string;
  avatar: string;
  text: string;
  time: string;
  replies?: Comment[];
}

interface Event {
  id: number;
  title: string;
  date: string;
  location: string;
  description: string;
  attendees: number;
  tokens: number;
  category: string;
  organizer: string;
  hasRequirements: boolean;
  comments: Comment[];
  status?: "active" | "applications_closed" | "completed";
  requirements?: {
    question: string;
    maxWords?: number;
    type?: "text" | "image";
  }[];
  maxApplicants?: number;
}

const allEvents: Event[] = [
  {
    id: 1,
    title: "Community Meeting Presentation",
    date: "Feb 15, 2026",
    location: "Main Auditorium",
    description:
      "Present your community service initiatives and earn Savannah points. Share your experiences and inspire others to get involved in community development.",
    attendees: 45,
    tokens: 150,
    category: "Presentation",
    organizer: "Leadership Center",
    hasRequirements: true,
    status: "active",
    maxApplicants: 60,
    comments: [
      {
        id: 1,
        user: "Sarah M.",
        avatar: "",
        text: "Can't wait for this event! Really looking forward to presenting my project.",
        time: "2 hours ago",
        replies: [],
      },
      {
        id: 2,
        user: "James K.",
        avatar: "",
        text: "Will there be refreshments provided?",
        time: "5 hours ago",
        replies: [
          {
            id: 101,
            user: "Admin",
            avatar: "",
            text: "Yes, refreshments will be provided after the presentations.",
            time: "4 hours ago",
          },
        ],
      },
      {
        id: 3,
        user: "Emily R.",
        avatar: "",
        text: "This is a great opportunity for freshmen to get involved!",
        time: "1 day ago",
        replies: [],
      },
    ],
  },
  {
    id: 8,
    title: "Leadership Skills Workshop",
    date: "Feb 18, 2026",
    location: "Conference Room B",
    description:
      "An intensive workshop on developing essential leadership skills. Limited seats available for this exclusive training session.",
    attendees: 25,
    tokens: 100,
    category: "Workshop",
    organizer: "Leadership Center",
    hasRequirements: true,
    status: "active",
    maxApplicants: 25,
    comments: [],
  },
  {
    id: 2,
    title: "Science Fair Project Exhibition",
    date: "Feb 20, 2026",
    location: "Science Building",
    description:
      "Showcase your innovative science projects to judges and peers. Demonstrate your research findings and compete for top honors.",
    attendees: 120,
    tokens: 200,
    category: "Exhibition",
    organizer: "Science Department",
    hasRequirements: true,
    status: "applications_closed",
    comments: [
      {
        id: 1,
        user: "Michael T.",
        avatar: "",
        text: "My team is working on a renewable energy project. Super excited!",
        time: "3 hours ago",
        replies: [],
      },
      {
        id: 2,
        user: "Lisa H.",
        avatar: "",
        text: "What's the deadline for project submissions?",
        time: "1 day ago",
        replies: [],
      },
    ],
  },
  {
    id: 3,
    title: "Adwa Week Celebration",
    date: "Mar 2, 2026",
    location: "School Grounds",
    description:
      "Participate in cultural activities celebrating Ethiopian heritage. Join performances, exhibitions, and educational sessions.",
    attendees: 300,
    tokens: 100,
    category: "Cultural",
    organizer: "Cultural Club",
    hasRequirements: false,
    status: "active",
    comments: [
      {
        id: 1,
        user: "Abebe D.",
        avatar: "",
        text: "This will be a wonderful celebration of our heritage!",
        time: "1 hour ago",
        replies: [],
      },
      {
        id: 2,
        user: "Helen M.",
        avatar: "",
        text: "Will there be traditional food?",
        time: "4 hours ago",
        replies: [],
      },
      {
        id: 3,
        user: "Daniel A.",
        avatar: "",
        text: "Looking forward to the traditional dance performances!",
        time: "6 hours ago",
        replies: [],
      },
      {
        id: 4,
        user: "Sara T.",
        avatar: "",
        text: "Can parents attend this event?",
        time: "2 days ago",
        replies: [],
      },
    ],
  },
  {
    id: 4,
    title: "Student Council Workshop",
    date: "Mar 10, 2026",
    location: "Conference Room A",
    description:
      "Learn about leadership skills, public speaking, and student governance. Perfect for aspiring student leaders.",
    attendees: 30,
    tokens: 75,
    category: "Workshop",
    organizer: "Student Council",
    hasRequirements: true,
    status: "completed",
    comments: [
      {
        id: 1,
        user: "Alex P.",
        avatar: "",
        text: "Great opportunity for future leaders!",
        time: "12 hours ago",
        replies: [],
      },
    ],
  },
  {
    id: 5,
    title: "Environmental Clean-up Drive",
    date: "Mar 15, 2026",
    location: "School Neighborhood",
    description:
      "Join us for a community clean-up initiative. Help beautify our neighborhood while earning Savannah points for service.",
    attendees: 85,
    tokens: 50,
    category: "Service",
    organizer: "Green Club",
    hasRequirements: false,
    status: "active",
    comments: [
      {
        id: 1,
        user: "Rachel G.",
        avatar: "",
        text: "Let's make our community cleaner! 🌱",
        time: "2 hours ago",
        replies: [],
      },
      {
        id: 2,
        user: "Tom W.",
        avatar: "",
        text: "Should we bring our own gloves?",
        time: "8 hours ago",
        replies: [],
      },
    ],
  },
  {
    id: 6,
    title: "Debate Competition Finals",
    date: "Mar 22, 2026",
    location: "Main Hall",
    description:
      "Watch the top debaters compete for the championship title. Audience participation Savannah points available.",
    attendees: 200,
    tokens: 25,
    category: "Competition",
    organizer: "Debate Society",
    hasRequirements: true,
    status: "applications_closed",
    comments: [
      {
        id: 1,
        user: "Chris L.",
        avatar: "",
        text: "The semi-finals were intense! Can't wait for the finals!",
        time: "1 day ago",
        replies: [],
      },
      {
        id: 2,
        user: "Nina S.",
        avatar: "",
        text: "What's the topic for the finals?",
        time: "2 days ago",
        replies: [],
      },
    ],
  },
  {
    id: 7,
    title: "Student Art Portfolio Showcase",
    date: "Mar 25, 2026",
    location: "Art Gallery Hall",
    description:
      "Submit your best artwork for display. Leadership will review and feature outstanding submissions. Requires image uploads of your artwork.",
    attendees: 85,
    tokens: 175,
    category: "Exhibition",
    organizer: "Leadership Center",
    hasRequirements: true,
    status: "active",
    requirements: [
      {
        question: "Describe your art style and inspiration",
        maxWords: 100,
        type: "text",
      },
      { question: "Upload your best artwork", type: "image" },
      {
        question: "Upload a photo of yourself with your artwork",
        type: "image",
      },
    ],
    comments: [
      {
        id: 1,
        user: "Maya K.",
        avatar: "",
        text: "So excited to showcase my paintings! This is a great opportunity for student artists.",
        time: "30 minutes ago",
        replies: [],
      },
      {
        id: 2,
        user: "Ryan T.",
        avatar: "",
        text: "What art mediums are accepted? Can I submit digital art?",
        time: "2 hours ago",
        replies: [
          {
            id: 201,
            user: "Admin",
            avatar: "",
            text: "Yes, all art mediums are welcome including digital art, paintings, sculptures (photos), and mixed media.",
            time: "1 hour ago",
          },
        ],
      },
      {
        id: 3,
        user: "Sophie L.",
        avatar: "",
        text: "Will there be prizes for the best submissions?",
        time: "5 hours ago",
        replies: [],
      },
    ],
  },
];

const categories = [
  "All",
  "Presentation",
  "Exhibition",
  "Cultural",
  "Workshop",
  "Service",
  "Competition",
];

export default function Events() {
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
  const currentUser = localStorage.getItem("userName") || "Student";
  const trimesterEnded = localStorage.getItem("trimesterEnded") === "true";

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [applicationDialogOpen, setApplicationDialogOpen] = useState(false);
  const [commentDialogOpen, setCommentDialogOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [eventComments, setEventComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [replyText, setReplyText] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState("");
  const [expandedReplies, setExpandedReplies] = useState<Set<number>>(
    new Set()
  );

  // Application form state
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [imageFiles, setImageFiles] = useState<Record<number, File | null>>({});
  const [imagePreviews, setImagePreviews] = useState<Record<number, string>>(
    {}
  );
  const [errors, setErrors] = useState<Record<number, string>>({});
  const fileInputRefs = useRef<Record<number, HTMLInputElement | null>>({});

  const countWords = (text: string): number => {
    return text
      .trim()
      .split(/\s+/)
      .filter((word) => word.length > 0).length;
  };

  const validateWordCount = (
    text: string,
    maxWords: number | undefined,
    idx: number
  ) => {
    if (!maxWords) return true;
    const wordCount = countWords(text);
    if (wordCount > maxWords) {
      setErrors((prev) => ({
        ...prev,
        [idx]: `Exceeds maximum of ${maxWords} words (currently ${wordCount})`,
      }));
      return false;
    } else {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[idx];
        return newErrors;
      });
      return true;
    }
  };

  const handleAnswerChange = (
    idx: number,
    value: string,
    maxWords?: number
  ) => {
    setAnswers({ ...answers, [idx]: value });
    if (maxWords) {
      validateWordCount(value, maxWords, idx);
    }
  };

  const handleImageUpload = (idx: number, file: File | null) => {
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image must be less than 5MB");
        return;
      }
      setImageFiles((prev) => ({ ...prev, [idx]: file }));
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreviews((prev) => ({
          ...prev,
          [idx]: e.target?.result as string,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleReplies = (commentId: number) => {
    setExpandedReplies((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(commentId)) {
        newSet.delete(commentId);
      } else {
        newSet.add(commentId);
      }
      return newSet;
    });
  };

  const filteredEvents = allEvents.filter((event) => {
    const matchesSearch =
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === "All" || event.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Track applied events
  const [appliedEventIds, setAppliedEventIds] = useState<Set<number>>(() => {
    const stored = localStorage.getItem("appliedEventIds");
    return stored ? new Set(JSON.parse(stored)) : new Set();
  });
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);

  const markAsApplied = (eventId: number) => {
    setAppliedEventIds((prev) => {
      const next = new Set(prev);
      next.add(eventId);
      localStorage.setItem("appliedEventIds", JSON.stringify([...next]));
      return next;
    });
  };

  const handleApply = (event: Event) => {
    if (!isLoggedIn) {
      toast.info("Please sign in to apply for events");
      return;
    }

    if (appliedEventIds.has(event.id)) return;

    if (event.hasRequirements) {
      setSelectedEvent(event);
      setAnswers({});
      setErrors({});
      setImageFiles({});
      setImagePreviews({});
      setApplicationDialogOpen(true);
    } else {
      setSelectedEvent(event);
      setConfirmModalOpen(true);
    }
  };

  const handleSubmitApplication = () => {
    if (!selectedEvent) return;

    if (selectedEvent.requirements && selectedEvent.requirements.length > 0) {
      const allAnswered = selectedEvent.requirements.every((req, idx) => {
        if (req.type === "image") {
          return imageFiles[idx] != null;
        }
        return answers[idx]?.trim();
      });

      if (!allAnswered) {
        toast.error("Please complete all requirements");
        return;
      }

      let hasErrors = false;
      selectedEvent.requirements.forEach((req, idx) => {
        if (req.maxWords && countWords(answers[idx] || "") > req.maxWords) {
          hasErrors = true;
          setErrors((prev) => ({
            ...prev,
            [idx]: `Exceeds maximum of ${req.maxWords} words`,
          }));
        }
      });

      if (hasErrors || Object.keys(errors).length > 0) {
        toast.error("Please fix word count errors before submitting");
        return;
      }
    }

    markAsApplied(selectedEvent.id);
    toast.success(`Successfully applied to "${selectedEvent.title}"!`);
    setApplicationDialogOpen(false);
    setSelectedEvent(null);
    setAnswers({});
    setErrors({});
    setImageFiles({});
    setImagePreviews({});
  };

  const handleOpenComments = (event: Event) => {
    setSelectedEvent(event);
    setEventComments([...event.comments]);
    setCommentDialogOpen(true);
  };

  const handleSubmitComment = () => {
    if (!newComment.trim()) {
      toast.error("Please write a comment");
      return;
    }
    if (!isLoggedIn) {
      toast.info("Please sign in to comment");
      return;
    }

    const comment: Comment = {
      id: Date.now(),
      user: currentUser,
      avatar: "",
      text: newComment.trim(),
      time: "Just now",
      replies: [],
    };

    setEventComments([comment, ...eventComments]);
    setNewComment("");
    toast.success("Comment posted successfully!");
  };

  const handleReply = (commentId: number) => {
    if (!replyText.trim()) return;
    if (!isLoggedIn) {
      toast.info("Please sign in to reply");
      return;
    }

    const reply: Comment = {
      id: Date.now(),
      user: currentUser,
      avatar: "",
      text: replyText.trim(),
      time: "Just now",
    };

    setEventComments(
      eventComments.map((comment) => {
        if (comment.id === commentId) {
          return {
            ...comment,
            replies: [reply, ...(comment.replies || [])],
          };
        }
        return comment;
      })
    );

    setReplyingTo(null);
    setReplyText("");
    toast.success("Reply posted!");
  };

  const handleEdit = (
    commentId: number,
    isReply?: boolean,
    parentId?: number
  ) => {
    if (!editText.trim()) return;

    if (isReply && parentId) {
      setEventComments(
        eventComments.map((comment) => {
          if (comment.id === parentId) {
            return {
              ...comment,
              replies: comment.replies?.map((reply) =>
                reply.id === commentId
                  ? { ...reply, text: editText.trim() }
                  : reply
              ),
            };
          }
          return comment;
        })
      );
    } else {
      setEventComments(
        eventComments.map((comment) =>
          comment.id === commentId
            ? { ...comment, text: editText.trim() }
            : comment
        )
      );
    }

    setEditingId(null);
    setEditText("");
    toast.success("Comment updated!");
  };

  const handleDelete = (
    commentId: number,
    isReply?: boolean,
    parentId?: number
  ) => {
    if (isReply && parentId) {
      setEventComments(
        eventComments.map((comment) => {
          if (comment.id === parentId) {
            return {
              ...comment,
              replies: comment.replies?.filter(
                (reply) => reply.id !== commentId
              ),
            };
          }
          return comment;
        })
      );
    } else {
      setEventComments(
        eventComments.filter((comment) => comment.id !== commentId)
      );
    }
    toast.success("Comment deleted!");
  };

  const startEdit = (comment: Comment) => {
    setEditingId(comment.id);
    setEditText(comment.text);
    setReplyingTo(null);
  };

  const renderReply = (reply: Comment, parentId: number) => (
    <div key={reply.id} className="flex gap-2 mt-2 ml-4">
      <CornerDownRight className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-2" />
      <Avatar className="h-7 w-7 flex-shrink-0">
        <AvatarImage src={reply.avatar} />
        <AvatarFallback className="bg-primary/10 text-primary font-semibold text-xs">
          {reply.user
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="p-2.5 rounded-lg bg-muted/50">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <span className="font-medium text-foreground text-xs">
                {reply.user}
              </span>
              <span className="text-xs text-muted-foreground">
                {reply.time}
              </span>
            </div>
            {reply.user === currentUser && editingId !== reply.id && (
              <div className="flex items-center gap-0.5">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-5 w-5"
                  onClick={() => startEdit(reply)}
                >
                  <Pencil className="h-2.5 w-2.5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-5 w-5 text-destructive hover:text-destructive"
                  onClick={() => handleDelete(reply.id, true, parentId)}
                >
                  <Trash2 className="h-2.5 w-2.5" />
                </Button>
              </div>
            )}
          </div>

          {editingId === reply.id ? (
            <div className="space-y-2">
              <Textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                rows={2}
                className="resize-none text-xs"
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 text-xs"
                  onClick={() => setEditingId(null)}
                >
                  <X className="h-3 w-3 mr-1" />
                  Cancel
                </Button>
                <Button
                  size="sm"
                  className="h-6 text-xs"
                  onClick={() => handleEdit(reply.id, true, parentId)}
                >
                  <Check className="h-3 w-3 mr-1" />
                  Save
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">{reply.text}</p>
          )}
        </div>
      </div>
    </div>
  );

  const renderComment = (comment: Comment) => {
    const hasReplies = comment.replies && comment.replies.length > 0;
    const isExpanded = expandedReplies.has(comment.id);
    const replyCount = comment.replies?.length || 0;

    return (
      <div key={comment.id} className="flex gap-3">
        <Avatar className="h-10 w-10 flex-shrink-0">
          <AvatarImage src={comment.avatar} />
          <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">
            {comment.user
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="p-3 rounded-lg bg-secondary/50">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground text-sm">
                  {comment.user}
                </span>
                <span className="text-xs text-muted-foreground">
                  {comment.time}
                </span>
              </div>
              {comment.user === currentUser && editingId !== comment.id && (
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => startEdit(comment)}
                  >
                    <Pencil className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-destructive hover:text-destructive"
                    onClick={() => handleDelete(comment.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              )}
            </div>

            {editingId === comment.id ? (
              <div className="space-y-2">
                <Textarea
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  rows={2}
                  className="resize-none text-sm"
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7"
                    onClick={() => setEditingId(null)}
                  >
                    <X className="h-3 w-3 mr-1" />
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    className="h-7"
                    onClick={() => handleEdit(comment.id)}
                  >
                    <Check className="h-3 w-3 mr-1" />
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">{comment.text}</p>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 mt-1">
            {editingId !== comment.id && isLoggedIn && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-muted-foreground hover:text-foreground"
                onClick={() => {
                  setReplyingTo(replyingTo === comment.id ? null : comment.id);
                  setReplyText("");
                  setEditingId(null);
                }}
              >
                <Reply className="h-3 w-3 mr-1" />
                Reply
              </Button>
            )}

            {/* View Replies Button */}
            {hasReplies && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-primary hover:text-primary hover:bg-primary/10"
                onClick={() => toggleReplies(comment.id)}
              >
                {isExpanded ? (
                  <>
                    <ChevronUp className="h-3 w-3 mr-1" />
                    Hide {replyCount} {replyCount === 1 ? "reply" : "replies"}
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-3 w-3 mr-1" />
                    View {replyCount} {replyCount === 1 ? "reply" : "replies"}
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Reply input */}
          {replyingTo === comment.id && (
            <div className="mt-2 flex gap-2">
              <Textarea
                placeholder="Write a reply..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                rows={2}
                className="resize-none text-sm flex-1"
              />
              <div className="flex flex-col gap-1">
                <Button
                  size="sm"
                  className="h-7"
                  onClick={() => handleReply(comment.id)}
                  disabled={!replyText.trim()}
                >
                  <Send className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7"
                  onClick={() => setReplyingTo(null)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          )}

          {/* Collapsible Replies */}
          {hasReplies && (
            <Collapsible
              open={isExpanded}
              onOpenChange={() => toggleReplies(comment.id)}
            >
              <CollapsibleContent className="space-y-1">
                {comment.replies?.map((reply) =>
                  renderReply(reply, comment.id)
                )}
              </CollapsibleContent>
            </Collapsible>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-hero py-16">
        <div className="container text-center">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-primary-foreground mb-4">
            Events
          </h1>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto">
            Discover opportunities to participate in school activities, develop
            leadership skills, and earn Savannah points.
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8">
        {trimesterEnded ? (
          <div className="p-8 rounded-lg border border-warning/50 bg-warning/10 text-center max-w-lg mx-auto">
            <AlertTriangle className="h-12 w-12 text-warning mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-warning mb-2">
              Trimester Ended
            </h3>
            <p className="text-muted-foreground">
              The current trimester has ended. All events are unavailable until
              a new trimester begins. Please check back later.
            </p>
          </div>
        ) : (
          <>
            {/* Filters */}
            <div className="flex flex-col md:flex-row gap-4 mb-8 justify-center items-center">
              <SearchInput
                placeholder="Search events..."
                value={searchQuery}
                onValueChange={setSearchQuery}
                containerClassName="w-full max-w-md"
              />
              <Select
                value={selectedCategory}
                onValueChange={setSelectedCategory}
              >
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Events Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEvents.map((event, index) => (
                <Card
                  key={event.id}
                  className="group overflow-hidden bg-card hover:shadow-card-hover transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="secondary">{event.category}</Badge>
                        {event.status === "applications_closed" && (
                          <Badge
                            variant="outline"
                            className="border-warning/50 text-warning bg-warning/10 gap-1"
                          >
                            <Ban className="h-3 w-3" />
                            Applications Closed
                          </Badge>
                        )}
                        {event.status === "completed" && (
                          <Badge
                            variant="outline"
                            className="border-success/50 text-success bg-success/10 gap-1"
                          >
                            <CheckCircle className="h-3 w-3" />
                            Completed
                          </Badge>
                        )}
                      </div>
                      <div className="px-3 py-1 rounded-full bg-success/10 text-success text-sm font-medium whitespace-nowrap">
                        +{event.tokens} Savannah
                      </div>
                    </div>
                    <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors mt-2">
                      {event.title}
                    </h3>
                  </CardHeader>

                  <CardContent className="pb-4">
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                      {event.description}
                    </p>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <User className="h-4 w-4" />
                        <span>{event.organizer}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Users className="h-4 w-4" />
                          <span>
                            {event.attendees}
                            {event.maxApplicants
                              ? `/${event.maxApplicants}`
                              : ""}{" "}
                            registered
                          </span>
                        </div>
                        <button
                          onClick={() => handleOpenComments(event)}
                          className="flex items-center gap-1.5 px-2 py-1 rounded-md text-primary bg-primary/10 hover:bg-primary/20 transition-colors cursor-pointer font-medium text-sm"
                        >
                          <MessageCircle className="h-4 w-4" />
                          <span>{event.comments.length}</span>
                        </button>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="pt-0">
                    {event.status === "completed" ? (
                      <Badge
                        variant="outline"
                        className="w-full justify-center py-2.5 border-success/50 text-success bg-success/5"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Event Completed
                      </Badge>
                    ) : event.status === "applications_closed" ||
                      (event.maxApplicants &&
                        event.attendees >= event.maxApplicants) ? (
                      <Badge
                        variant="outline"
                        className="w-full justify-center py-2.5 border-warning/30 text-warning bg-warning/5"
                      >
                        <Ban className="h-4 w-4 mr-2" />
                        {event.maxApplicants &&
                        event.attendees >= event.maxApplicants
                          ? "No Spots Available"
                          : "Applications Closed"}
                      </Badge>
                    ) : appliedEventIds.has(event.id) ? (
                      <Badge
                        variant="outline"
                        className="w-full justify-center py-2.5 border-primary/50 text-primary bg-primary/5"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Already Applied
                      </Badge>
                    ) : isLoggedIn ? (
                      <Button
                        onClick={() => handleApply(event)}
                        className="w-full"
                      >
                        Apply Now
                      </Button>
                    ) : (
                      <Button asChild className="w-full">
                        <Link to="/login">Sign In to Apply</Link>
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>

            {filteredEvents.length === 0 && (
              <div className="text-center py-16">
                <div className="flex justify-center mb-4">
                  <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                    <CalendarX className="h-8 w-8 text-muted-foreground" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  No Events Found
                </h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  We couldn't find any events matching your criteria. Try
                  adjusting your search or filter settings.
                </p>
              </div>
            )}
          </>
        )}
      </div>

      {/* Application Dialog */}
      <Dialog
        open={applicationDialogOpen}
        onOpenChange={setApplicationDialogOpen}
      >
        <DialogContent className="w-[calc(100%-2rem)] sm:max-w-lg p-4 sm:p-6">
          <DialogHeader className="pb-2">
            <DialogTitle className="text-base sm:text-lg pr-6">
              Apply for {selectedEvent?.title}
            </DialogTitle>
            <DialogDescription className="text-sm">
              Fill out the requirements below.
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[55vh] pr-4 -mr-4">
            <div className="space-y-4 py-2 px-1">
              {selectedEvent?.requirements &&
              selectedEvent.requirements.length > 0 ? (
                selectedEvent.requirements.map((req, idx) => {
                  const wordCount = countWords(answers[idx] || "");
                  const hasError = errors[idx];
                  const isImageType = req.type === "image";

                  return (
                    <div key={idx} className="space-y-2">
                      <Label className="flex items-center gap-2 text-sm">
                        {isImageType && (
                          <ImageIcon className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-muted-foreground shrink-0" />
                        )}
                        <span className="line-clamp-2">{req.question}</span>
                      </Label>

                      {isImageType ? (
                        <div className="space-y-2">
                          <input
                            type="file"
                            accept="image/*"
                            ref={(el) => {
                              fileInputRefs.current[idx] = el;
                            }}
                            onChange={(e) =>
                              handleImageUpload(
                                idx,
                                e.target.files?.[0] || null
                              )
                            }
                            className="hidden"
                          />

                          {imagePreviews[idx] ? (
                            <div className="relative">
                              <img
                                src={imagePreviews[idx]}
                                alt="Preview"
                                className="w-full h-32 sm:h-40 object-cover rounded-lg border"
                              />
                              <Button
                                type="button"
                                variant="secondary"
                                size="sm"
                                className="absolute bottom-2 right-2 text-xs"
                                onClick={() =>
                                  fileInputRefs.current[idx]?.click()
                                }
                              >
                                Change
                              </Button>
                            </div>
                          ) : (
                            <div
                              onClick={() =>
                                fileInputRefs.current[idx]?.click()
                              }
                              className="flex flex-col items-center justify-center w-full h-24 sm:h-32 border-2 border-dashed rounded-lg cursor-pointer hover:bg-secondary/50 transition-colors"
                            >
                              <Upload className="h-6 w-6 sm:h-8 sm:w-8 text-muted-foreground mb-2" />
                              <p className="text-xs sm:text-sm text-muted-foreground">
                                Click to upload
                              </p>
                              <p className="text-[10px] sm:text-xs text-muted-foreground">
                                Max 5MB
                              </p>
                            </div>
                          )}
                        </div>
                      ) : req.maxWords && req.maxWords > 10 ? (
                        <Textarea
                          placeholder="Enter your answer..."
                          value={answers[idx] || ""}
                          onChange={(e) =>
                            handleAnswerChange(
                              idx,
                              e.target.value,
                              req.maxWords
                            )
                          }
                          rows={req.maxWords > 100 ? 4 : 3}
                          className={`text-sm ${
                            hasError
                              ? "border-destructive focus-visible:ring-destructive"
                              : ""
                          }`}
                        />
                      ) : (
                        <Input
                          placeholder="Enter your answer..."
                          value={answers[idx] || ""}
                          onChange={(e) =>
                            handleAnswerChange(
                              idx,
                              e.target.value,
                              req.maxWords
                            )
                          }
                          className={`text-sm ${
                            hasError
                              ? "border-destructive focus-visible:ring-destructive"
                              : ""
                          }`}
                        />
                      )}

                      {!isImageType && (
                        <div className="flex items-center justify-between">
                          {req.maxWords && (
                            <p
                              className={`text-xs ${
                                hasError
                                  ? "text-destructive font-medium"
                                  : "text-muted-foreground"
                              }`}
                            >
                              {hasError
                                ? errors[idx]
                                : `${wordCount}/${req.maxWords}`}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="motivation" className="text-sm">
                      Why do you want to participate?
                    </Label>
                    <Textarea
                      id="motivation"
                      placeholder="Share your motivation..."
                      rows={4}
                      className="text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="experience" className="text-sm">
                      Relevant Experience
                    </Label>
                    <Textarea
                      id="experience"
                      placeholder="Describe any relevant experience..."
                      rows={3}
                      className="text-sm"
                    />
                  </div>
                </>
              )}
            </div>
          </ScrollArea>
          <DialogFooter className="gap-2 sm:gap-0 pt-2">
            <Button
              variant="outline"
              onClick={() => setApplicationDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitApplication}
              className="w-full sm:w-auto"
            >
              Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Comments Dialog */}
      <Dialog open={commentDialogOpen} onOpenChange={setCommentDialogOpen}>
        <DialogContent className="sm:max-w-lg h-[80vh] flex flex-col p-0 gap-0 overflow-hidden">
          <DialogHeader className="p-6 pb-2">
            <DialogTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-primary" />
              Comments
            </DialogTitle>
            <DialogDescription className="line-clamp-1">
              {selectedEvent?.title}
            </DialogDescription>
          </DialogHeader>

          {/* flex-1 allows this area to grow and take up all available vertical space */}
          <ScrollArea className="flex-1 px-6">
            <div className="space-y-6 py-4">
              {eventComments.length === 0 ? (
                <div className="text-center py-12">
                  <MessageCircle className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground text-sm font-medium">
                    No comments yet.
                  </p>
                  <p className="text-muted-foreground/60 text-xs">
                    Be the first to start the conversation!
                  </p>
                </div>
              ) : (
                eventComments.map((comment) => renderComment(comment))
              )}
            </div>
          </ScrollArea>

          <div className="p-4 bg-background border-t">
            <div className="flex gap-2 items-center">
              <Avatar className="h-8 w-8 hidden sm:flex">
                <AvatarFallback className="text-[10px] bg-primary/10 text-primary">
                  {currentUser
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-1 gap-2">
                <Input
                  placeholder={
                    isLoggedIn ? "Write a comment..." : "Sign in to comment"
                  }
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  disabled={!isLoggedIn}
                  onKeyDown={(e) => e.key === "Enter" && handleSubmitComment()}
                  className="flex-1 bg-muted/50 border-none focus-visible:ring-1"
                />
                <Button
                  size="icon"
                  onClick={handleSubmitComment}
                  disabled={!isLoggedIn || !newComment.trim()}
                  className="shrink-0"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
            {!isLoggedIn && (
              <p className="text-[10px] text-center text-muted-foreground mt-2">
                You must be logged in to participate.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirmation Modal for events without requirements */}
      <AlertDialog open={confirmModalOpen} onOpenChange={setConfirmModalOpen}>
        <AlertDialogContent className="w-[calc(100%-2rem)] max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Application</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to apply for "{selectedEvent?.title}"? This
              action will register you for the event.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedEvent) {
                  markAsApplied(selectedEvent.id);
                  toast.success(
                    `Successfully applied to "${selectedEvent.title}"!`
                  );
                  setSelectedEvent(null);
                }
              }}
            >
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
